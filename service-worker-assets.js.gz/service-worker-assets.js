self.assetsManifest = {
  "version": "qJs5J1i+",
  "assets": [
    {
      "hash": "sha256-u4RFkSIRF4ZUGYO82nwVMd1LgN3gD0UfON+fEiUH/rM=",
      "url": "_content/eTasks.Components/eTasks.Components.rwqm3ky6eg.bundle.scp.css"
    },
    {
      "hash": "sha256-uh3bYKVz13422gDK5Htg6k/cakr5oMgBTZC+QD9qiBY=",
      "url": "_content/eTasks.View/eTasks.View.2ekmdsv4ow.bundle.scp.css"
    },
    {
      "hash": "sha256-V/lZB5qS645SIk40rNBSDGmgjxjMNB4Vn5xGM7DhcsM=",
      "url": "_framework/Microsoft.AspNetCore.Components.3xrgwaw2dp.wasm"
    },
    {
      "hash": "sha256-v+uwBWlsF4iCHG6B9ZA8x3jlos/84zEJCWdcqZNu3Sk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.tx885whulx.wasm"
    },
    {
      "hash": "sha256-TMJrwxmh7raq50FXlf8OFb9/PXWC0dJ48IVhshQE3jE=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.ojjbeuchn6.wasm"
    },
    {
      "hash": "sha256-yxPiW+l2bwpbqQMt+LqIVyoudbaoHWuYPnD4DDJUr88=",
      "url": "_framework/Microsoft.Extensions.Configuration.7p4o2tpul4.wasm"
    },
    {
      "hash": "sha256-Vaey6KNbQjvV5f4sgTb9Z7DpC7i8fKGaG8HGFaV0O8k=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.79qfazjlcu.wasm"
    },
    {
      "hash": "sha256-e7KqvUYccR78CImWVq5kLp49gK7pPVNLuAnrrJ59tXE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.lo1485j0el.wasm"
    },
    {
      "hash": "sha256-e8G0JQI0dUUudPzWdfamVDGrSV+tqr50McBL0FMtaGo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ynt3oix6u.wasm"
    },
    {
      "hash": "sha256-9gNtu6CvoWhJqo9wkrnbQ8SHNpP8Z94dA2LSPvixCqw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.uajpihyy0l.wasm"
    },
    {
      "hash": "sha256-bhMyrU5Kmxq6U/Pm8Oj+c31HPzzV9IgKVwFK2lkpmO8=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.6rwj86mmew.wasm"
    },
    {
      "hash": "sha256-Rw3p7P7cbetsRUa1O+Q7ltdFAmR7kf26guR3xO9aq3s=",
      "url": "_framework/Microsoft.Extensions.Logging.fugc9tzrx1.wasm"
    },
    {
      "hash": "sha256-aghFR5ix2EFcXsXxIjilRm2GirVLMF7NAkzXIR0Y9JY=",
      "url": "_framework/Microsoft.Extensions.Options.er9kaksr7l.wasm"
    },
    {
      "hash": "sha256-DnlMLnoUShENHHG/1JwJlFyv8wwJ0wNnr/fEV/sR2dI=",
      "url": "_framework/Microsoft.Extensions.Primitives.2jafe63jbt.wasm"
    },
    {
      "hash": "sha256-sGms9Oai1ztzgfMsqBvmeKwa5ZyGWr/AEXr6thw0lso=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.8eb000j8w7.wasm"
    },
    {
      "hash": "sha256-LuYfR4a5fwfclUwXPnTjZGpINIjF23AhCZmTFWP2xbQ=",
      "url": "_framework/Microsoft.JSInterop.iknej2zdh8.wasm"
    },
    {
      "hash": "sha256-61G6RdWky6wSKMoiBGmJfoebCUZviZ5ID5YVq4HzR40=",
      "url": "_framework/System.Collections.Concurrent.fzjfrdn2ak.wasm"
    },
    {
      "hash": "sha256-HtRM8z6SWCHMrKQrNZIALzy2FMivErM+NlMU8wP0mA4=",
      "url": "_framework/System.Collections.Immutable.2sznr7iy82.wasm"
    },
    {
      "hash": "sha256-RrOCBAu0fykaRKnDXyXK9NVkaBBbUMTAFJjTuvUBFDA=",
      "url": "_framework/System.Collections.u6x9vx00i0.wasm"
    },
    {
      "hash": "sha256-NQkKskUXENdTSf2C0+y41sjKi68CHmUqCgPPLNxKyGw=",
      "url": "_framework/System.ComponentModel.h9eo79o86x.wasm"
    },
    {
      "hash": "sha256-s9sOP9t+76Zhz0IlLQuIbiiqP+wfqhUbCbOpvNOekDc=",
      "url": "_framework/System.Console.by2rwprruu.wasm"
    },
    {
      "hash": "sha256-13F6UCivKZPw1YCWlsitkOJtrLcBhCD2EXnx2WDWpKE=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.pse11zgi9v.wasm"
    },
    {
      "hash": "sha256-PquLWMEc3QwTVtiyuC/O26Mjg5zxQrco0vYOXs6r4ZQ=",
      "url": "_framework/System.IO.Pipelines.ijgegc6dgx.wasm"
    },
    {
      "hash": "sha256-y0AKAUNDbvlOl0ajqq19MSAXrLlmHCfKHya/LYRVh/k=",
      "url": "_framework/System.Linq.3u5tm2uqab.wasm"
    },
    {
      "hash": "sha256-SrBVMo6y8K0FW1a07/LPx+E73mNBQDIPA1+IPvft0aI=",
      "url": "_framework/System.Memory.acxyzgdz32.wasm"
    },
    {
      "hash": "sha256-46btkK5gB4RtnUv0nbokEIt/QwEAyK8jsMY5Od8aTGI=",
      "url": "_framework/System.Net.Http.Json.nv7km3wylk.wasm"
    },
    {
      "hash": "sha256-OoHikCo/Wjtjge40ngYMjjR8s2nLuqPTLkGmSLwLhRI=",
      "url": "_framework/System.Net.Http.mt1oqep2xb.wasm"
    },
    {
      "hash": "sha256-RZU3+AurzUeBWgVjZalkA1jPlfRnehNr+R49gyYTuFI=",
      "url": "_framework/System.Net.Primitives.3uow9zd1kc.wasm"
    },
    {
      "hash": "sha256-azuNufqYklzWfc03qs+K/OiVnspuMFTvz1f5Kc6Ar0c=",
      "url": "_framework/System.Private.CoreLib.hhut9v8a6w.wasm"
    },
    {
      "hash": "sha256-OY/kwLeSs+r2Ci5ssjPahAaSWKIwmyhfQJAwcBPvQ7A=",
      "url": "_framework/System.Private.Uri.vq43m4ppq9.wasm"
    },
    {
      "hash": "sha256-pbuetxobAOn+JttKb23nU8Or27wYSz7U6Go0ecGi24M=",
      "url": "_framework/System.Runtime.7lqnyvy0fo.wasm"
    },
    {
      "hash": "sha256-r+LQmgoVdHgFKWJvUNAR7HQZAtSw+xvBIQ6siSPsBNM=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.f4ln4hfftw.wasm"
    },
    {
      "hash": "sha256-Nf8NaUHo7Okrl6blRawAL2OuaeYzEUEpV8g4f3JHIdE=",
      "url": "_framework/System.Text.Encodings.Web.5k2l7qr163.wasm"
    },
    {
      "hash": "sha256-xnoVoDiTHavVRVWIwoQtz3XV1rrYCHybLgh+lTyAyWE=",
      "url": "_framework/System.Text.Json.6du2n67neb.wasm"
    },
    {
      "hash": "sha256-SKkTQL9D0Loskr+NX705/WITcRNb/8VQlQorMrz5S6M=",
      "url": "_framework/System.Text.RegularExpressions.0e9rlv7vxy.wasm"
    },
    {
      "hash": "sha256-24inb9qHwMgt3KIjfomf+IHFhkJlGDDhcK8ivbFO8Z0=",
      "url": "_framework/System.Threading.jmn9lxh1h2.wasm"
    },
    {
      "hash": "sha256-EuGS8bgFuB9MQYDFABh9hokG/M+poqPdas5CNx04nTY=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-/pcrNUZIFxvVrfML8zazMdEZ+IB0TdSKqJ6mAPvV+w4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-HFADmT26AarHu4tMjFaTPxINmQjBJGtdPN+CKjtNMFE=",
      "url": "_framework/dotnet.native.8bti36lthm.js"
    },
    {
      "hash": "sha256-F3/BArijJUydqmwcdWeW3LYyYHBRSu2+pyy8GL1jTV0=",
      "url": "_framework/dotnet.native.tr0cyonrwt.wasm"
    },
    {
      "hash": "sha256-82FoDmY+LsehdN2u8aSGEutGEKXJHcYaSX/3zptbsCw=",
      "url": "_framework/dotnet.runtime.tsg4gsv2hg.js"
    },
    {
      "hash": "sha256-i6VkYA8dL5JnzJZy7zT7pR+w3+fpRjDSkiVhBpXiVrU=",
      "url": "_framework/eFirebase4CSharp.frv3mfveo7.wasm"
    },
    {
      "hash": "sha256-FqoKIF55FQfJShpbZYfriNKNVdwyoIml5Lzb9xZByqs=",
      "url": "_framework/eTasks.Components.aga8jbz1it.wasm"
    },
    {
      "hash": "sha256-IxesMwcYYv1i70ErPbBFsYDge7AvKgJdSQNjePk0dk4=",
      "url": "_framework/eTasks.Shared.zw4putwb60.wasm"
    },
    {
      "hash": "sha256-c/FuT3uhmr5xryJH4sDmxnahku7s0tODdkq3XEp0Pt4=",
      "url": "_framework/eTasks.View.nfojnewqak.wasm"
    },
    {
      "hash": "sha256-S5Tx5xYya7BXbhLAGzZ0DtEGbyj2BKQY2vKD8F256PY=",
      "url": "_framework/eTasks.frrrfc36zu.wasm"
    },
    {
      "hash": "sha256-Ys/5ICwGLiR1NuhuMSAtDaRH3a6FnwLX4TT+/ctn9Kw=",
      "url": "_framework/eTranslate.m750dy0r6n.wasm"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-2Go9Cdf6w5sym57hBt7ipc3vAsJ6DGx8WRFB0CI9mUA=",
      "url": "assets/UI/Avatar2.png"
    },
    {
      "hash": "sha256-JxXepGCi4j3rkyGA1Mgnrho+vE8ri1JvK9mImmaC1Ao=",
      "url": "assets/UI/avatar/dark/Avatar.png"
    },
    {
      "hash": "sha256-IHK/OZzrHu/4rlUn5njWUc6OBM3WUn+ljmGz2Nviv+c=",
      "url": "assets/UI/avatar/dark/ChangePassword.png"
    },
    {
      "hash": "sha256-8k1jyLLHQI8w7dhuNUBJVXyoyXE2NjLLjfH1Q+X/ST8=",
      "url": "assets/UI/avatar/dark/EditProfile.png"
    },
    {
      "hash": "sha256-bAXOlQJvtvl3POcT59sD4Ms0sRg+M8HHK/dh8CthiOo=",
      "url": "assets/UI/avatar/dark/Logout.png"
    },
    {
      "hash": "sha256-wrYUlIsdtosbLUZ0qctPpXCSn+7zNgJIJFhGPcc8dOk=",
      "url": "assets/UI/avatar/dark/menu/config.png"
    },
    {
      "hash": "sha256-XHnafJuJgEASuvYDySJfv+4vCwfJ7UW5EyABRGKbiEk=",
      "url": "assets/UI/avatar/dark/menu/conquista.png"
    },
    {
      "hash": "sha256-u57Uru7+qSLnr1fiex5pkravpJLMPVj5X7zjJtxzQZQ=",
      "url": "assets/UI/avatar/dark/menu/idioma.png"
    },
    {
      "hash": "sha256-j6ngmkN6olzdk1+HMKtW4NyCgWx7HOUzDgUkMN6RXcA=",
      "url": "assets/UI/avatar/dark/menu/sobre.png"
    },
    {
      "hash": "sha256-TzFaG29Qu9BLApnzEO5ir2+KuOqJiSlIO8AmqwFVD2U=",
      "url": "assets/UI/avatar/dark/menu/tema.png"
    },
    {
      "hash": "sha256-VMErV7SKCP0+98uIPzAD9kSVoamLbu20L/vvnyJvBaQ=",
      "url": "assets/UI/avatar/light/Avatar.png"
    },
    {
      "hash": "sha256-XALEsBJzGq0LG81fI6itxN650FLS2DAia1LkeNwCtkI=",
      "url": "assets/UI/avatar/light/ChangePassword.png"
    },
    {
      "hash": "sha256-gwTyMSjWxBdfQlBpnYMfVGhEHw9AESkXnQ89jwl5OEQ=",
      "url": "assets/UI/avatar/light/EditProfile.png"
    },
    {
      "hash": "sha256-F9/m5mhG+4U5FAuDEaBMaA2DAU0s2OaLiPQGU6outho=",
      "url": "assets/UI/avatar/light/Logout.png"
    },
    {
      "hash": "sha256-faxcSsxU5MG6OXD6RTpezKtqoeT09cA41cv8W6ruLTo=",
      "url": "assets/UI/avatar/light/menu/config.png"
    },
    {
      "hash": "sha256-P5yrRwG2laF9R/S+1UlRcM3p8NgI8X+zfv/YrBcYHm8=",
      "url": "assets/UI/avatar/light/menu/conquista.png"
    },
    {
      "hash": "sha256-8Cgoz3qEGUOw8J4Vj8wn0fMx1rYeBj//JKAhbN/WSDI=",
      "url": "assets/UI/avatar/light/menu/idioma.png"
    },
    {
      "hash": "sha256-XKllgfaz5mN05Us1LHDrx3lyzGgG0AhKaUP0G1U7xW8=",
      "url": "assets/UI/avatar/light/menu/sobre.png"
    },
    {
      "hash": "sha256-GUP4Lrl62WcdU6kUpSY4Q0LEes/eGjtaZAf+hQUJjns=",
      "url": "assets/UI/avatar/light/menu/tema.png"
    },
    {
      "hash": "sha256-ZeJ5C2l8nLBEX7+frY8JJTtR+BE36H5ERwrgAkP9Jck=",
      "url": "assets/UI/common/Accept.png"
    },
    {
      "hash": "sha256-5kXBtA9z7WozECkB5P3WVpEZyI6P9vGOC3WK/ix+ZUs=",
      "url": "assets/UI/common/Add.png"
    },
    {
      "hash": "sha256-ScB/CiUKAvZzIy1d61pG0hO/oScJa9EGfvx2zkjiGRY=",
      "url": "assets/UI/common/Clear.png"
    },
    {
      "hash": "sha256-D98kxkaXPNKcDhO5XULbb48+NqcVnMLGI6Dx/yKiFDI=",
      "url": "assets/UI/languages/en.svg"
    },
    {
      "hash": "sha256-mLBEPcMpuMAVlQujg56aFIeFBfeuQJ2Qzu/YFHks43Y=",
      "url": "assets/UI/languages/pt.svg"
    },
    {
      "hash": "sha256-qfOm0aACcgIc7mCZDVNS747EN3ymz2qAZKGrTeIInbs=",
      "url": "assets/UI/mainmenu/dark/anotacoes.png"
    },
    {
      "hash": "sha256-KzED1b+aL4Wv275dKWcWZMuh1o6jYUeYl0Qu2Kk1jDc=",
      "url": "assets/UI/mainmenu/dark/compras.png"
    },
    {
      "hash": "sha256-dns3wBE3sqZ9t9HH05A5jFPNI/OvsdBS0iydkiRgV0c=",
      "url": "assets/UI/mainmenu/dark/financas.png"
    },
    {
      "hash": "sha256-Z3mea1qrI1dRYGQbMXbJTaKHFP2/qcQx+G1sVxHAnQo=",
      "url": "assets/UI/mainmenu/dark/inicio.png"
    },
    {
      "hash": "sha256-rjrr1zHvyf3Nez3Yq+GRg14XzO4C+WmvZGG5kGtxCFo=",
      "url": "assets/UI/mainmenu/dark/leituras.png"
    },
    {
      "hash": "sha256-ZEaVtTA5dICbskyRnDvYDGn1G9N9XRusCQCBjR41GrA=",
      "url": "assets/UI/mainmenu/dark/metas.png"
    },
    {
      "hash": "sha256-dFUDugtJVrC918dCEUYM3VsFKFJaSnOI9Ffk31rX1Z8=",
      "url": "assets/UI/mainmenu/dark/tarefas.png"
    },
    {
      "hash": "sha256-Ob/cHanx/ZaG31yAQONU1uA4Fgp02iPCd0UGoOTGaU4=",
      "url": "assets/UI/mainmenu/light/anotacoes.png"
    },
    {
      "hash": "sha256-C6bcLDvcA1LhOItGJYAzIKYLjpCsUSKVccaIhcpQZDw=",
      "url": "assets/UI/mainmenu/light/compras.png"
    },
    {
      "hash": "sha256-R27uxSa9K5CrBnyR/ndcI0qYDBiavYr8q2EvcV6OPO0=",
      "url": "assets/UI/mainmenu/light/financas.png"
    },
    {
      "hash": "sha256-ucufobkj/tOo4HsiX8DtZ5YMOk3BNVP3KZ0jIXCE/LM=",
      "url": "assets/UI/mainmenu/light/inicio.png"
    },
    {
      "hash": "sha256-y+xf+BityFucZKnWlTE3rfDiYhI4093MzH6lKTc6i3c=",
      "url": "assets/UI/mainmenu/light/leituras.png"
    },
    {
      "hash": "sha256-ApQxbuobGzrWkQ7lhxZ7IWYvSJx0e0fjdENOiec9uVo=",
      "url": "assets/UI/mainmenu/light/metas.png"
    },
    {
      "hash": "sha256-Hb6qV63skgGn7pf82ruiGvReYhCHYFNTx3hmNufUqns=",
      "url": "assets/UI/mainmenu/light/tarefas.png"
    },
    {
      "hash": "sha256-n+IQxBhag7MkVVgoly+Kn664piSdCzTdRiU1VZBQUYc=",
      "url": "assets/UI/offcanvas/dark/Close.png"
    },
    {
      "hash": "sha256-uoTV9HzeiRyLpuZpvL0qU9KYBT6iWmDnWIqqG3Ne8VU=",
      "url": "assets/UI/offcanvas/light/Close.png"
    },
    {
      "hash": "sha256-ZeJ5C2l8nLBEX7+frY8JJTtR+BE36H5ERwrgAkP9Jck=",
      "url": "assets/UI/toolbar/dark/Accept.png"
    },
    {
      "hash": "sha256-b+Gl6LUdGbeid8QqizlRq+cSymQv6yyYq4Y7v/O+NZo=",
      "url": "assets/UI/toolbar/dark/BackBtn.png"
    },
    {
      "hash": "sha256-ScB/CiUKAvZzIy1d61pG0hO/oScJa9EGfvx2zkjiGRY=",
      "url": "assets/UI/toolbar/dark/Clear.png"
    },
    {
      "hash": "sha256-ihlzhFoErncyIcjJlm/AR+h5RiOlNLGWk4HjoZrEvN8=",
      "url": "assets/UI/toolbar/dark/Delete.png"
    },
    {
      "hash": "sha256-y7SC48mGCf3HUBBFRt7l1Pw9nOpDzrPiVh73gE3JRWI=",
      "url": "assets/UI/toolbar/dark/Help.png"
    },
    {
      "hash": "sha256-UNfl3Ms488dtblXubcHMAW4AuYXMBLwlRMb4O6mloHs=",
      "url": "assets/UI/toolbar/dark/MainMenu.png"
    },
    {
      "hash": "sha256-TzFaG29Qu9BLApnzEO5ir2+KuOqJiSlIO8AmqwFVD2U=",
      "url": "assets/UI/toolbar/dark/ThemeChanger.png"
    },
    {
      "hash": "sha256-mXjLpCAAAasmeCfqxc0rS3q450GIDzCu6PehidXI0MY=",
      "url": "assets/UI/toolbar/dark/Update.png"
    },
    {
      "hash": "sha256-ZeJ5C2l8nLBEX7+frY8JJTtR+BE36H5ERwrgAkP9Jck=",
      "url": "assets/UI/toolbar/light/Accept.png"
    },
    {
      "hash": "sha256-lnL7WPYxRPmb6SPb8vkmjsADHTpYk5Fn/nZmZMmVgyE=",
      "url": "assets/UI/toolbar/light/BackBtn.png"
    },
    {
      "hash": "sha256-ScB/CiUKAvZzIy1d61pG0hO/oScJa9EGfvx2zkjiGRY=",
      "url": "assets/UI/toolbar/light/Clear.png"
    },
    {
      "hash": "sha256-ihlzhFoErncyIcjJlm/AR+h5RiOlNLGWk4HjoZrEvN8=",
      "url": "assets/UI/toolbar/light/Delete.png"
    },
    {
      "hash": "sha256-chZdrFpFFroSWfXJzgRK/ODYgho6vjnQOl76ipW2MRc=",
      "url": "assets/UI/toolbar/light/Help.png"
    },
    {
      "hash": "sha256-jhoXCQcTA9VquzeATA4jTPpgUtNYdvfY/dkXwdnIfJY=",
      "url": "assets/UI/toolbar/light/MainMenu.png"
    },
    {
      "hash": "sha256-OmxBBsRWRVN5ws0jlNSku06IB9IJEvCc7uW5U/wg/og=",
      "url": "assets/UI/toolbar/light/ThemeChanger.png"
    },
    {
      "hash": "sha256-4zomsMTmvuF95hCU4tYfAv4ZKJN8WAUckcb3HfFU294=",
      "url": "assets/UI/toolbar/light/Update.png"
    },
    {
      "hash": "sha256-vbYmxvfPpo+/apk8LROyFAy8BipZbACA0Jcln36lnRs=",
      "url": "assets/favicon.png"
    },
    {
      "hash": "sha256-wvq5zSFvetVRbtqdx6jyD6pR9PgEJFDKrNdtahdgr/k=",
      "url": "assets/icon-192.png"
    },
    {
      "hash": "sha256-dTSkdywJq9Jdbt9QnQubZhbyXJLzzX5qifA40bfhHSc=",
      "url": "assets/icon-512.png"
    },
    {
      "hash": "sha256-9IsOCewvHji/MAUP4ZBi4brY5ZJQXP7mGDgeHIovmx8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-fx038NkLY4U1TCrBDiu5FWPEa9eiZu01EiLryshJbCo=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-AwPSbVxr+DKi7Fn117kFWP1HJYYTXBiiYOhJvoPq4zQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-YadjLKoaxSw0ZXHi9q5P1BvGJ99htFFVoO8UN/ftkJU=",
      "url": "eTasks.styles.css"
    },
    {
      "hash": "sha256-xiTuf/dUeahAtvDiTIUf0QF8Ll5jAyaQstct/zMkDKQ=",
      "url": "index.html"
    },
    {
      "hash": "sha256-SWymZFkT0BQM8ZU8SRDm0of7nkDOoBK2JiycBhTGeik=",
      "url": "js/ResizeCore.js"
    },
    {
      "hash": "sha256-cylxV1UruqmvQwOaplblZ7N+bxLCJYH+vHSBhlz5kF4=",
      "url": "js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-gvZPYrsDwbwYJLD5yeBfcNujPhRoGOY831wwbIzz3t0=",
      "url": "js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-GaWwuI0k1rFUxEYolsljHAsxfXHyLuu/C55AXbQ1H9E=",
      "url": "js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-fjUoYYaEBY+/zOQfkJNlzDrtbi8xuK0gZlF8vsyx9Ws=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-MrMSWo75MyIKcQYfGB8IW9E0GqDJhhwVLM3TN0nkQ28=",
      "url": "translate.json"
    }
  ]
};
